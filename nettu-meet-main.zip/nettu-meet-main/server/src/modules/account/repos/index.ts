import { MongoAccountRepo } from './implementations/mongoAccountRepo';

const accountRepo = new MongoAccountRepo();

export { accountRepo };
