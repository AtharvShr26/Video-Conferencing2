export interface ResourceDTO {
    id: string;
    publicURL: string;
    name: string;
    contentType: string;
    canvasId?: string;
}
