export interface CanvasDTO {
    id: string;
    data: string;
}
