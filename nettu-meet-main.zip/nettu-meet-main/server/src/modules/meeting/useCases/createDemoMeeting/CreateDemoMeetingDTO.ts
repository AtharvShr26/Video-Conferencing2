export interface CreateDemoMeetingDTO {}
