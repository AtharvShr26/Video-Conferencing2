import { MongoChatRepo } from './implementations/mongoChatRepo';

const chatRepo = new MongoChatRepo();

export { chatRepo };
