import { AccountService } from "./accountService";

const accountService = new AccountService();

export { accountService };
