import { UserService } from "./userService";

const userService = new UserService();

export { userService };
