import { MeetingService } from "./meetingService";

const meetingService = new MeetingService();

export { meetingService };
